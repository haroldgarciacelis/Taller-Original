package co.com.nequi.dynamodb.model;


import lombok.*;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@ToString
@DynamoDbBean
public class UserSystemDynamoDbEntity {

    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String avatar;



    @DynamoDbPartitionKey
    public Long getId() {
        return id;
    }


}
