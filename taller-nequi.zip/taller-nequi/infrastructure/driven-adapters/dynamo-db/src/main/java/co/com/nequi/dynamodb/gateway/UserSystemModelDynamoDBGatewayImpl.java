package co.com.nequi.dynamodb.gateway;

import co.com.nequi.dynamodb.DynamoDBTemplateAdapter;
import co.com.nequi.model.usersystem.gateways.UserSystemModelDynamoDBGateway;
import co.com.nequi.model.userplataform.UserSystemModel;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@AllArgsConstructor
@Primary
public class UserSystemModelDynamoDBGatewayImpl implements UserSystemModelDynamoDBGateway {

    private final DynamoDBTemplateAdapter dynamoDBTemplateAdapter;


    @Override
    public Mono<UserSystemModel> save(UserSystemModel userSystemModel) {
        System.out.println("User-----------------------------------");
        System.out.println("userSystemModel: " +userSystemModel.toString());
     return dynamoDBTemplateAdapter.save(userSystemModel);
    }
}
