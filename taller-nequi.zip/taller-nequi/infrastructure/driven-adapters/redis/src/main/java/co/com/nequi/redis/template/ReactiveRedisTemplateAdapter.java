package co.com.nequi.redis.template;

import co.com.nequi.model.usersystem.gateways.UserSystemModelRedisGateway;
import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.redis.template.dto.UserDataCache;
import co.com.nequi.redis.template.helper.ReactiveTemplateAdapterOperations;
import lombok.extern.slf4j.Slf4j;
import org.reactivecommons.utils.ObjectMapper;
import org.springframework.data.redis.connection.ReactiveRedisConnectionFactory;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Component
@Slf4j
public class ReactiveRedisTemplateAdapter extends ReactiveTemplateAdapterOperations<UserSystemModel, String, UserDataCache>
 implements UserSystemModelRedisGateway {
    public ReactiveRedisTemplateAdapter(ReactiveRedisConnectionFactory connectionFactory, ObjectMapper mapper) {
        /**
         *  Could be use mapper.mapBuilder if your domain model implement builder pattern
         *  super(repository, mapper, d -> mapper.mapBuilder(d,ObjectModel.ObjectModelBuilder.class).build());
         *  Or using mapper.map with the class of the object model
         */
        super(connectionFactory, mapper, d -> mapper.map(d, UserSystemModel.class/* change for domain model */));
    }

    private static final long EXPIRATION_TIME = 600000;

    @Override
    public Mono<UserSystemModel> getById(Long id) {
        return findById(generateKey(id))
                .doOnSubscribe(sb -> log.info("Buscando en cache el usuario con Id {}", id))
                .doOnNext(usr -> log.info("El usuario con Id {} fue encontrado en cache", usr.getId()))
                .onErrorResume(error -> Mono.empty());
    }

    @Override
    public Mono<UserSystemModel> save(UserSystemModel user) {
        return save(generateKey(user.getId()), user, EXPIRATION_TIME)
                .doOnSubscribe(sb -> log.info("Guardando en cache el usuario con Id {}", user.getId()))
                .doOnNext(usr -> log.info("El usuario con Id {} fue guardado en cache", usr.getId()))
                .onErrorResume(error -> Mono.empty());
    }

    private String generateKey(Long id) {
        return String.format("userSystem:%d", id.hashCode());
    }
}