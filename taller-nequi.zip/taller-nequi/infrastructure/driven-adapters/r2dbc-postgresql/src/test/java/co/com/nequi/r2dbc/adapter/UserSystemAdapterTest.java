package co.com.nequi.r2dbc.adapter;

import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.r2dbc.entity.UserOnboardingEntity;
import co.com.nequi.r2dbc.mapper.UserOnboardingMapper;
import co.com.nequi.r2dbc.repository.UserOnboardingEntityRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;


@ExtendWith(MockitoExtension.class)
class UserSystemAdapterTest {

    @Mock
    private UserOnboardingEntityRepository userOnboardingEntityRepository;

    @Mock
    private UserOnboardingMapper userOnboardingMapper;

    @InjectMocks
    private UserSystemAdapter userSystemAdapter;

    @Test
    void getFindById() {
        Long id = 1l;

        UserOnboardingEntity entity = UserOnboardingEntity.builder()
                .id(id)
                .idUser(2L)
                .firstName("Andres")
                .lastName("Ospina")
                .email("felipeospina21@gmail.com")
                .avatar("avatar").build();

        UserSystemModel userSystemModel = UserSystemModel.builder()
                        .id(2L)
                .firstName("Andres")
                .lastName("Ospina")
                .email("felipeospina21@gmail.com")
                .avatar("avatar").build();

        Mockito.when(userOnboardingEntityRepository.findByIdUser(anyLong())).thenReturn(Mono.just(entity));
        Mockito.when(userOnboardingMapper.toModel(any(UserOnboardingEntity.class))).thenReturn(userSystemModel);

        Mono<UserSystemModel> result = userSystemAdapter.getFindById(id);
        StepVerifier.create(result)
                .expectNext(userSystemModel)
                .verifyComplete();


    }
}