package co.com.nequi.r2dbc.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.annotation.Id;

import org.springframework.data.relational.core.mapping.Column;
import org.springframework.data.relational.core.mapping.Table;



@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table("user_onboarding")
public class UserOnboardingEntity {

    @Id
    private Long id;

    @Column("id_user")
    private Long idUser;


    @Column("email")
    private String email;


    @Column("first_name")
    private String firstName;


    @Column("last_name")
    private String lastName;


    @Column("avatar")
    private String avatar;



}
