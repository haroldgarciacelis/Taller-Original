package co.com.nequi.r2dbc.adapter;

import co.com.nequi.model.usersystem.gateways.UserSystemModelDBGateway;
import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.r2dbc.entity.UserOnboardingEntity;
import co.com.nequi.r2dbc.mapper.UserOnboardingMapper;
import co.com.nequi.r2dbc.repository.UserOnboardingEntityRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static net.logstash.logback.argument.StructuredArguments.kv;

@Component
@AllArgsConstructor
@Slf4j
public class UserSystemAdapter implements UserSystemModelDBGateway {

    private final UserOnboardingEntityRepository userOnboardingEntityRepository;
    private final UserOnboardingMapper userOnboardingMapper;


    @Override
    public Mono<UserSystemModel> getFindById(Long id) {
        Mono<UserOnboardingEntity> entity = userOnboardingEntityRepository.findByIdUser(id);
        return entity.map(userOnboardingMapper::toModel);
    }

    @Override
    public Mono<UserSystemModel> save(UserSystemModel userSystemModel) {
        UserOnboardingEntity entity = userOnboardingMapper.toEntity(userSystemModel);
        entity.setId(null);
        return userOnboardingEntityRepository.save(entity)
                .map(userOnboardingMapper::toModel);

    }

    @Override
    public Flux<UserSystemModel> getAll() {
        Flux<UserOnboardingEntity> list = userOnboardingEntityRepository.findAll();
        return list.map(userOnboardingMapper::toModel);
    }

    @Override
    public Flux<UserSystemModel> getByFirstName(String firstName) {
        Flux<UserOnboardingEntity> entity = userOnboardingEntityRepository.getByFirstName(firstName);
        return entity.map(userOnboardingMapper::toModel);
    }


}
