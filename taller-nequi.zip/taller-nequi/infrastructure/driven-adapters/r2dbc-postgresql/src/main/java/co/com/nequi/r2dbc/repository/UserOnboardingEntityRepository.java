package co.com.nequi.r2dbc.repository;

import co.com.nequi.r2dbc.entity.UserOnboardingEntity;
import org.springframework.data.r2dbc.repository.Query;
import org.springframework.data.repository.reactive.ReactiveCrudRepository;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Repository
public interface UserOnboardingEntityRepository extends ReactiveCrudRepository<UserOnboardingEntity, Long> {

    @Query("SELECT * FROM user_onboarding WHERE id_user =:id")
    Mono<UserOnboardingEntity> findByIdUser(Long id);

    @Query("SELECT * FROM user_onboarding WHERE LOWER(first_name) LIKE LOWER(CONCAT('%', :firstName, '%'))")
    Flux<UserOnboardingEntity> getByFirstName(String firstName);

}
