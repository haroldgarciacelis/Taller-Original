package co.com.nequi.r2dbc.mapper;


import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.r2dbc.entity.UserOnboardingEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;


@Mapper(componentModel = "spring")
public interface UserOnboardingMapper {

    @Mapping(source = "idUser", target = "id")
    UserSystemModel toModel(UserOnboardingEntity userOnboardingEntity);

    @Mapping(source = "id", target = "idUser")
    UserOnboardingEntity toEntity(UserSystemModel userSystemModel);
}
