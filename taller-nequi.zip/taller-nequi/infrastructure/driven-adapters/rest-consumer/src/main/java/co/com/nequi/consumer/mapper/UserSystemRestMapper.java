package co.com.nequi.consumer.mapper;


import co.com.nequi.consumer.response.UserResponse;
import co.com.nequi.model.userplataform.UserSystemModel;
import org.mapstruct.Mapper;



@Mapper(componentModel = "spring")
public interface UserSystemRestMapper {

    UserSystemModel toDomain(UserResponse userResponse);


}
