package co.com.nequi.consumer.response;

import com.fasterxml.jackson.annotation.JsonProperty;

public record UserResponse(Long id,
                           String email,
                           @JsonProperty("first_name") String firstName,
                           @JsonProperty("last_name")  String lastName,
                           String avatar) {
}
