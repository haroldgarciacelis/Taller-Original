package co.com.nequi.consumer.response;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserReqresResponse {
    private UserResponse data;
}
