package co.com.nequi.consumer.rest;

import co.com.nequi.consumer.mapper.UserSystemRestMapper;
import co.com.nequi.consumer.response.UserReqresResponse;
import co.com.nequi.model.usersystem.exceptions.UserSystemWebClientException;
import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.model.usersystem.gateways.UserSystemModelWebClientGateway;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserSystemRestConsumer  implements UserSystemModelWebClientGateway {

    private final WebClient webClient;
    private final UserSystemRestMapper userSystemRestMapper;

    @Override
    public Mono<UserSystemModel> getById(Long id) {
        Map<String, Object> params = Map.of("id", id);
        return webClient
                .get()
                .uri("/users/{id}", params)
                .retrieve()
                .onStatus(httpStatusCode -> httpStatusCode == HttpStatus.NOT_FOUND, response -> response.bodyToMono(String.class)
                        .flatMap( bodyReponse -> Mono.error(new UserSystemWebClientException("El usuario no existe en el api reeqres: " ,  response.statusCode().value()))))
                .onStatus(HttpStatusCode::is5xxServerError,
                        response -> response.bodyToMono(String.class)
                                .flatMap(bodyResponse -> Mono.error(new UserSystemWebClientException(bodyResponse, response.statusCode().value()))))
                .bodyToMono(UserReqresResponse.class)
                .log()
                .map(response -> userSystemRestMapper.toDomain(response.getData()));
    }
}
