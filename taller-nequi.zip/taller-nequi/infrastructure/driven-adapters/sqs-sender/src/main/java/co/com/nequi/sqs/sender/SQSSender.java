package co.com.nequi.sqs.sender;

import co.com.nequi.model.usersystem.gateways.SqsSendGateway;
import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.sqs.sender.config.SQSSenderProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.services.sqs.SqsAsyncClient;
import software.amazon.awssdk.services.sqs.model.SendMessageRequest;
import software.amazon.awssdk.services.sqs.model.SendMessageResponse;


@Service
@Log4j2
@RequiredArgsConstructor
public class SQSSender implements SqsSendGateway {

    private final SQSSenderProperties properties;
    private final SqsAsyncClient client;
    private final ObjectMapper objectMapper;

    @Override
    public Mono<String> send(UserSystemModel userSystemModel) {

        return Mono.fromCallable(() -> convertToJson(userSystemModel))
                .flatMap(json -> Mono.fromCallable(() -> buildRequest(json)))
                .flatMap(request -> Mono.fromFuture(client.sendMessage(request)))
                .doOnSuccess(response -> log.info("Message sent with id: {}", response.messageId()))
                .map(SendMessageResponse::messageId);
    }
    private String convertToJson(UserSystemModel userSystemModel) throws JsonProcessingException {
        return objectMapper.writeValueAsString(userSystemModel);
    }

    private SendMessageRequest buildRequest(String message) {
        return SendMessageRequest.builder()
                .queueUrl(properties.queueUrl())
                .messageBody(message)
                .build();
    }



}
