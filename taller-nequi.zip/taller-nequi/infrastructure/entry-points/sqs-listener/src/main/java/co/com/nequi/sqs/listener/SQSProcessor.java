package co.com.nequi.sqs.listener;

import co.com.nequi.model.usersystem.exceptions.UserSystemSqlReceiverException;
import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.usecase.usersystem.UserSystemModelUseCase;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import software.amazon.awssdk.services.sqs.model.Message;

import java.util.Map;
import java.util.function.Function;

import static net.logstash.logback.argument.StructuredArguments.kv;

@Service
@RequiredArgsConstructor
@Slf4j
public class SQSProcessor implements Function<Message, Mono<Void>> {


    private final ObjectMapper objectMapper;
    private final UserSystemModelUseCase userSystemModelUseCase;

    @Override
    public Mono<Void> apply(Message message) {
       return Mono.just(message.body())
               .flatMap(this::parseMessageBody)
               .flatMap(userSystemModelUseCase::save)
               .doOnNext(userSystemModel ->{
                       Map<String,String> data = Map.of("id", userSystemModel.getId().toString(), "email", userSystemModel.getEmail(), "firstName", userSystemModel.getFirstName(), "lastName", userSystemModel.getLastName());
                       log.info("Se guarda la información del usuario", kv("userSystemModel", data));
               })
               .then()
               .doOnSuccess(aVoid -> log.info("Se guarda la información del usuario y se completa"))
               .doOnError(error -> log.error("Si se presenta un error", error));

    }

    private Mono<UserSystemModel> parseMessageBody(String messageBody) {
        try {
            UserSystemModel userSystemModel = objectMapper.readValue(messageBody, UserSystemModel.class);
            return Mono.just(userSystemModel);
        } catch (Exception e) {
            log.error("Error al convertir el cuerpo del mensaje", e);
            return Mono.error(new UserSystemSqlReceiverException("El formato es invalido", 400));
        }
    }
}
