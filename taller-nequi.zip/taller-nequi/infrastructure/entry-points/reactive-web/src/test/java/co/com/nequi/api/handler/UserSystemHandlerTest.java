package co.com.nequi.api.handler;

import co.com.nequi.api.constant.ConstantMessage;
import co.com.nequi.api.dto.GeneralResponseDto;
import co.com.nequi.api.helps.GenerateResponseHelp;
import co.com.nequi.model.userplataform.UserSystemModel;
import co.com.nequi.usecase.usersystem.UserSystemModelUseCase;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.reactive.function.server.MockServerRequest;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;

@ExtendWith(MockitoExtension.class)
class UserSystemHandlerTest {

    @Mock
    private UserSystemModelUseCase userSystemUseCase;

    @Mock
    private GenerateResponseHelp generateResponseHelp;

    @InjectMocks
    private UserSystemHandler userSystemHandler;

    @Test
    void getFindById() {

        String userId = "1";


        ServerRequest request = MockServerRequest.builder()
                .pathVariable("id", userId).build();

        UserSystemModel userSystemModel = UserSystemModel.builder()
                .id(1L)
                .firstName("Andres")
                .lastName("Ospina")
                .email("felipeospina21@gmail.com")
                .avatar("avatar").build();

        GeneralResponseDto generalResponseDto =  new GeneralResponseDto<>(true, HttpStatus.OK.value(),  ConstantMessage.SUCCEFULLY_STORED, userSystemModel);

        Mockito.when(userSystemUseCase.getById(anyLong())).thenReturn(Mono.just(userSystemModel));

        Mockito.when(generateResponseHelp.getUserResponseDto(any(UserSystemModel.class))).thenReturn(generalResponseDto);

        Mono<ServerResponse> result = userSystemHandler.getFindById(request);
        StepVerifier.create(result)
                .consumeNextWith(serverResponse -> {
                    assertEquals(HttpStatus.OK, serverResponse.statusCode());

                }).verifyComplete();

    }
}