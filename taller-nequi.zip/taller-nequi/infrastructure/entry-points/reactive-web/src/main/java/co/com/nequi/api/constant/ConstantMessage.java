package co.com.nequi.api.constant;

public class ConstantMessage {
    public static final String SUCCEFULLY_STORED = "Se obtiene la información del usuario";
    public static final String ERROR_STORED = "Se genera un error interno";
    private ConstantMessage(){}
}
