package co.com.nequi.api.router;

import co.com.nequi.api.handler.UserSystemHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

@Configuration
public class UserSystemRouter {

    @Bean
    public RouterFunction<ServerResponse> userRooters(UserSystemHandler handler) {
        return RouterFunctions
                .route()
                .POST("/user", handler::createUser)
                .GET("/user/{id}", handler::getFindById)
                .GET("/users", handler::getFindAll)
                .POST("/user/first-name", handler::getFindByFirstName)
                .build();
    }
}
