package co.com.nequi.api.handler;

import co.com.nequi.api.helps.GenerateResponseHelp;
import co.com.nequi.api.request.UseRequestSaveDto;
import co.com.nequi.api.request.UserRequestFindByFirstNameDto;
import co.com.nequi.model.usersystem.exceptions.UserSystemModelUseCaseException;
import co.com.nequi.usecase.usersystem.UserSystemModelUseCase;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.server.ServerRequest;
import org.springframework.web.reactive.function.server.ServerResponse;
import reactor.core.publisher.Mono;


@Component
@RequiredArgsConstructor
@Slf4j
public class UserSystemHandler {

    private final UserSystemModelUseCase userSystemUseCase;
    private final GenerateResponseHelp generateResponseHelp;

    public Mono<ServerResponse> createUser(ServerRequest request){
        Mono<UseRequestSaveDto> useRequestSaveDto = request.bodyToMono(UseRequestSaveDto.class);

        return  useRequestSaveDto.flatMap(useRequestSave ->
                  userSystemUseCase.saveUsingWebClient(useRequestSave.id())
                  .flatMap(userSystemModel ->
                                  ServerResponse.ok()
                                          .contentType(MediaType.APPLICATION_JSON)
                                          .bodyValue(generateResponseHelp.getUserResponseDto(userSystemModel))
                          )
                 .onErrorResume(UserSystemModelUseCaseException.class, e ->
                                 ServerResponse.status(e.getStatusCode())
                                         .contentType(MediaType.APPLICATION_JSON)
                                         .bodyValue(generateResponseHelp.generateError(e.getMessage()))

                ));

    }

    public Mono<ServerResponse> getFindById(ServerRequest request){
        Long id = Long.valueOf(request.pathVariable("id"));
        return userSystemUseCase.getById(id)
                .flatMap(userSystemModel ->
                        ServerResponse.ok()
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(generateResponseHelp.getUserResponseDto(userSystemModel))
                )
                .onErrorResume(UserSystemModelUseCaseException.class, e ->
                        ServerResponse.status(e.getStatusCode())
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(generateResponseHelp.generateError(e.getMessage()))

                );
    }

    public Mono<ServerResponse> getFindAll(ServerRequest request){

        return userSystemUseCase.getAll()
                .collectList()
                .flatMap(list ->
                        ServerResponse.ok()
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(generateResponseHelp.getUserAllResponseDto(list))
                ).onErrorResume(UserSystemModelUseCaseException.class, e ->
                        ServerResponse.status(e.getStatusCode())
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(generateResponseHelp.generateError(e.getMessage()))

                );
    }

    public Mono<ServerResponse> getFindByFirstName(ServerRequest request) {
        Mono<UserRequestFindByFirstNameDto> userRequestFindByFirstNameDto = request.bodyToMono(UserRequestFindByFirstNameDto.class);

        return userRequestFindByFirstNameDto.flatMap(firstNameDto ->
                        userSystemUseCase.getByFirstName(firstNameDto.firstName())
                                .collectList()
                                .flatMap(list ->
                        ServerResponse.ok()
                                .contentType(MediaType.APPLICATION_JSON)
                                .bodyValue(generateResponseHelp.getUserAllResponseDto(list))
                )
                        .onErrorResume(UserSystemModelUseCaseException.class, e ->
                                ServerResponse.status(e.getStatusCode())
                                        .contentType(MediaType.APPLICATION_JSON)
                                        .bodyValue(generateResponseHelp.generateError(e.getMessage()))

                ));
    }





    }
