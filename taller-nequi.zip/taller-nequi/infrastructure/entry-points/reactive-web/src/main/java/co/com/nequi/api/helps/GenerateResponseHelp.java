package co.com.nequi.api.helps;

import co.com.nequi.api.constant.ConstantMessage;
import co.com.nequi.api.dto.GeneralResponseDto;
import co.com.nequi.model.userplataform.UserSystemModel;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class GenerateResponseHelp {

    public GeneralResponseDto<UserSystemModel> getUserResponseDto(UserSystemModel userSystemModel){
        return new GeneralResponseDto<>(true, HttpStatus.OK.value(),  ConstantMessage.SUCCEFULLY_STORED, userSystemModel);

    }

    public GeneralResponseDto<List<UserSystemModel>> getUserAllResponseDto(List<UserSystemModel> list){
        return new GeneralResponseDto<>(true, HttpStatus.OK.value(),  ConstantMessage.SUCCEFULLY_STORED, list);

    }

    public GeneralResponseDto<String> getMessageSqsResponseDto(String message){
        return new GeneralResponseDto<>(true, HttpStatus.OK.value(),  ConstantMessage.SUCCEFULLY_STORED, message);

    }


    public GeneralResponseDto<String> generateError(String message) {
        return new GeneralResponseDto<>(false, HttpStatus.INTERNAL_SERVER_ERROR.value(),  ConstantMessage.ERROR_STORED, message);

    }
}
