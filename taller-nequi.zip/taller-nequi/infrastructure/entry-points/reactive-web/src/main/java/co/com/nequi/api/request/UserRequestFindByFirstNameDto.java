package co.com.nequi.api.request;

public record UserRequestFindByFirstNameDto(String firstName) {
}
