package co.com.nequi.api.request;

public record UseRequestSaveDto(Long id) {
}
