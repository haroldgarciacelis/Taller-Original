package co.com.nequi.usecase.usersystem;


import co.com.nequi.model.usersystem.exceptions.UserSystemModelUseCaseException;
import co.com.nequi.model.usersystem.exceptions.UserSystemWebClientException;
import co.com.nequi.model.usersystem.gateways.*;
import co.com.nequi.model.userplataform.UserSystemModel;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.core.scheduler.Schedulers;

@RequiredArgsConstructor
public class UserSystemModelUseCase {

    private final UserSystemModelWebClientGateway userSystemWebClientGateway;
    private final UserSystemModelDBGateway userSystemDBGateway;
    private final UserSystemModelRedisGateway userSystemModelRedisGateway;
    private final SqsSendGateway sqsGateway;
    private final UserSystemModelDynamoDBGateway  userSystemModelDynamoDBGateway;

    public Mono<UserSystemModel> saveUsingWebClient(Long id){
        return userSystemModelRedisGateway.getById(id)
                .switchIfEmpty(userSystemDBGateway.getFindById(id)
                        .switchIfEmpty(Mono.defer(() -> userSystemWebClientGateway.getById(id)
                                .onErrorMap(error ->
                                {
                                    if (error instanceof UserSystemWebClientException ue) {
                                        return new UserSystemModelUseCaseException(ue.getMessage(), ue.getStatusCode());
                                    }
                                    return error;
                                })
                                .flatMap(userSystemDBGateway::save)
                                .flatMap(userSystemModelRedisGateway::save)
                                .doOnSuccess(userSystemModel -> Mono.defer(()  -> sqsGateway.send(userSystemModel))
                                        .subscribeOn(Schedulers.parallel())
                                        .subscribe())


                        )));

    }



    public Mono<UserSystemModel> getById(Long id){

          return userSystemModelRedisGateway.getById(id)
               .switchIfEmpty(userSystemDBGateway.getFindById(id)
                  .switchIfEmpty(Mono.error(new UserSystemModelUseCaseException("No se encontro el usuario", 400))));
    }

    public Flux<UserSystemModel> getAll(){
        return userSystemDBGateway.getAll()
                .switchIfEmpty(Mono.error(new UserSystemModelUseCaseException("No se encontraron usuarios", 400)));

    }

    public Flux<UserSystemModel> getByFirstName(String firstName){
        return userSystemDBGateway.getByFirstName(firstName)
                .switchIfEmpty(Mono.error(new UserSystemModelUseCaseException("No se encontro usuarios con ese nombre", 400)));
    }

    public Mono<UserSystemModel> save(UserSystemModel userSystemModel){
        return this.transformUserSystemModelToUpperCase(userSystemModel)
                .flatMap(userSystemModelDynamoDBGateway::save);
    }



    public Mono<UserSystemModel> transformUserSystemModelToUpperCase(UserSystemModel userSystemModel) {
        return Mono.just(UserSystemModel.builder()
                .id(userSystemModel.getId())
                .email(userSystemModel.getEmail().toUpperCase())
                .firstName(userSystemModel.getFirstName().toUpperCase())
                .lastName(userSystemModel.getLastName().toUpperCase())
                .avatar(userSystemModel.getAvatar().toUpperCase())
                .build());
    }


}
