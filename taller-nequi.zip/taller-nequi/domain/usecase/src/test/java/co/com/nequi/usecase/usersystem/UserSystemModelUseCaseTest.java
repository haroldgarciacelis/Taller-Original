package co.com.nequi.usecase.usersystem;

import co.com.nequi.model.usersystem.gateways.*;
import co.com.nequi.model.userplataform.UserSystemModel;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;


@ExtendWith(MockitoExtension.class)
class UserSystemModelUseCaseTest {

    @Mock
    private UserSystemModelWebClientGateway userSystemWebClientGateway;

    @Mock
    private UserSystemModelDBGateway userSystemDBGateway;

    @Mock
    private UserSystemModelRedisGateway userSystemModelRedisGateway;

    @Mock
    private SqsSendGateway sqsGateway;

    @Mock
    private SQSReceiverGateway sqsReceiverGateway;

    @Mock
    private UserSystemModelDynamoDBGateway  userSystemModelDynamoDBGateway;

    @InjectMocks
    private UserSystemModelUseCase userSystemModelUseCase;

    @Test
    void saveUsingWebClient() {
        Long userId = 1L;

        UserSystemModel userSystemModel = UserSystemModel.builder()
                .id(userId)
                .firstName("Andres")
                .lastName("Ospina")
                .email("felipeospina21@gmail.com")
                .avatar("avatar")
                .build();


        Mockito.when(userSystemModelRedisGateway.getById(anyLong())).thenReturn(Mono.empty());
        Mockito.when(userSystemDBGateway.getFindById(anyLong())).thenReturn(Mono.empty());
        Mockito.when(userSystemWebClientGateway.getById(anyLong())).thenReturn(Mono.just(userSystemModel));
        Mockito.when(userSystemDBGateway.save(any(UserSystemModel.class))).thenReturn(Mono.just(userSystemModel));
        Mockito.when(userSystemModelRedisGateway.save(any(UserSystemModel.class))).thenReturn(Mono.just(userSystemModel));
        Mockito.when(sqsGateway.send(any(UserSystemModel.class))).thenReturn(Mono.just("Test"));

        Mono<UserSystemModel> result = userSystemModelUseCase.saveUsingWebClient(1L);

        StepVerifier.create(result)
                .expectNext(userSystemModel)
                .verifyComplete();


    }
}