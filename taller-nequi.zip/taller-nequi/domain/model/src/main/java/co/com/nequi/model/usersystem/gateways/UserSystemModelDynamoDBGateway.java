package co.com.nequi.model.usersystem.gateways;

import co.com.nequi.model.userplataform.UserSystemModel;
import reactor.core.publisher.Mono;

public interface UserSystemModelDynamoDBGateway {

    Mono<UserSystemModel> save(UserSystemModel userSystemModel);
}
