package co.com.nequi.model.usersystem.gateways;

import co.com.nequi.model.userplataform.UserSystemModel;
import reactor.core.publisher.Mono;

public interface UserSystemModelWebClientGateway {

    Mono<UserSystemModel> getById(Long id);
}
