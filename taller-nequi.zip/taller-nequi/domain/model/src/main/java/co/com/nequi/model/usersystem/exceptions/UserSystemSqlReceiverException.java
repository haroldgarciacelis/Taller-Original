package co.com.nequi.model.usersystem.exceptions;

import lombok.Getter;

@Getter
public class UserSystemSqlReceiverException extends RuntimeException {
   private int statusCode;
    public UserSystemSqlReceiverException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
