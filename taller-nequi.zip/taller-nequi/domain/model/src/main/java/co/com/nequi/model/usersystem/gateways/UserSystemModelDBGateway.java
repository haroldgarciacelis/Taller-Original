package co.com.nequi.model.usersystem.gateways;

import co.com.nequi.model.userplataform.UserSystemModel;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

public interface UserSystemModelDBGateway {

    Mono<UserSystemModel> getFindById(Long id);
    Mono<UserSystemModel> save(UserSystemModel userSystemModel);
    Flux<UserSystemModel> getAll();
    Flux<UserSystemModel> getByFirstName(String firstName);
}
