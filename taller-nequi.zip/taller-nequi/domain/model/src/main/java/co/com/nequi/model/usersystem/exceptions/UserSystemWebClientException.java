package co.com.nequi.model.usersystem.exceptions;

import lombok.Getter;

@Getter
public class UserSystemWebClientException extends RuntimeException {
    private int statusCode;
    public UserSystemWebClientException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
