package co.com.nequi.model.usersystem.exceptions;

import lombok.Getter;

@Getter
public class UserSystemModelUseCaseException extends RuntimeException {
    private int statusCode;
    public UserSystemModelUseCaseException(String message, int statusCode) {
        super(message);
        this.statusCode = statusCode;
    }
}
