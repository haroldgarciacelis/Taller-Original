package co.com.nequi.model.userplataform;
import lombok.*;



@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Builder(toBuilder = true)
public class UserSystemModel {

    private Long id;
    private String email;
    private String firstName;
    private String lastName;
    private String avatar;

}
