package co.com.nequi.model.usersystem.gateways;

import co.com.nequi.model.userplataform.UserSystemModel;
import reactor.core.publisher.Mono;

public interface UserSystemModelRedisGateway {
    Mono<UserSystemModel> getById(Long id);
    Mono<UserSystemModel> save(UserSystemModel user);
}
